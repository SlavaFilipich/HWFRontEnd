package com.company;

public class Part9 {
    /*
    10. Реализовать метод, который int findLastCharIndex(String str, char ch) который возвращает
позицию последнего вхождения (индекс) символа ch в строке str. Если символа в строке
нет, возвращаем -1.
Например: find(“let’s talk about java”,’t’) -> 15
     */
    public static void main(String[] args) {
        String str = "Java is great";
        char ch = 'a';
        System.out.println(str.lastIndexOf(ch));
    }
}
