package com.company;

public class Part55 {
    public static void main(String[] args) {
        /* 5.Реализовать метод String longestString (String str1, String str2, String str2) который
возвращает самую длинную строку из трех заданных строк:
Подсказка: Используйте метод, написанный в пункте 4
Например: longestString (“java”,”welcome”,”hello”) -> “welcome”
         */
        String str_A = "abc";
        String str_B = "abcd";
        String str_C = "abcdedd";
        int Max = Math.max(str_A.length(), Math.max(str_B.length(), str_C.length()));
        System.out.println("Max longest string value is " + Max);
    }
}
