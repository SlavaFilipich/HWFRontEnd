package com.company;

public class Part10 {
    /*
    12. Реализовать метод, который возвращает длину общего постфикса двух строк, т.е. сколько
символов начиная с конца одинаковые у обеих строк.
     */
    public static void main(String[] args) {
        String txt1 = "ABCD";
        String txt2 = "ad";
        int a = txt1.length();
        int b = txt2.length();
        int Strings_length = a + b;
        System.out.println("Strings length is:" + Strings_length);
    }
}

