package com.company;

public class Part8 {
    /* 9.Реализовать метод, который int findFirstCharIndex(String str, char ch) который возвращает
позицию первого вхождения (индекс) символа ch в строке str. Если символа в строке нет,
возвращаем -1.
Например: find(“let’s talk about java”,’t’) -> 2
*/
    public static void main(String[] args) {
        String str = "Java is great";
        char ch = 'a';
        System.out.println(str.indexOf(ch));
    }


}
