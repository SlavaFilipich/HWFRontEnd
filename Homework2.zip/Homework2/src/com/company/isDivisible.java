package com.company;

public class isDivisible {
    public static void main(String[] args) {
        /*
        2.Реализовать метод boolean isDivisible(int number1, int number2) который возвращает
true если number1 делится на number2 без остатка. Аналогично первой задаче
реализовать метод печати результата.
*/
        int a = 3;
        int b = 2;
        if (a % b == 0) {
            System.out.println("Good");
        } else {
            System.out.println("Not Good");

        }
    }
}
