package com.company;

public class Part3 {
    public static void main(String[] args) {
        /*
        3. Реализовать метод, который в качестве параметров получает 3 числа типа инт. Метод
должен возвращать true если и первое и второе число делятся без остатка на третье.
Подсказка: Используйте метод, написанный в пункте 2
*/
        int a = 12;
        int b = 8;
        int c = 4;
        if (a % c == 0 && b % c == 0) {
            System.out.println("Good");
        } else {
            System.out.println("Not Good");

        }
    }

}

