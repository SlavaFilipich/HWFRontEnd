package com.company;

public class Part4 {
    /*
   4. Реализовать метод int max3(int num1, int num2, int num3) который возвращает число,
наибольшее из трех переданных чисел:
Например: max3(10,19,0) -> 19
    */
    public static void main(String[] args) {
        int num1 = 3;
        int num2 = 7;
        int num3 = 5;
        int Max = Math.max(num1, Math.max(num2, num3));
        System.out.println("Max value is " + Max);

    }

}

