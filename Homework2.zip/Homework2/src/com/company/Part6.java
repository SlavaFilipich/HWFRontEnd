package com.company;

public class Part6 {
    /* 6.Реализовать метод, который печатает все числа в диапазоне от 0 до 100, которые не
делятся на 4
     */

    public static void main(String[] args) {
        int a = 100;
        int i = 0;

            for (i = 0; i < a; i++) {
                if (i%4 == 0) {
                    continue;
                }
                System.out.println(i);
            }
        }
    }