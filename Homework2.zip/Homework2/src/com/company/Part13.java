package com.company;

public class Part13 {
    /*
    14. Реализовать метод, который возвращает часть заданной строки, начиная с позиции start,
заканчивая позицией finish. (разбирали в классе, но можно реализовать самостоятельно).
Например: substring(“let’s talk about java”, 7,20) -> “talk about ja”
     */
    public static void main(String[] args){
        String string = "Hello";
        System.out.println(substring(string, 3, 5));
    }

    public static String substring(String str, int start, int finish) {
        String result = "";
        for (int i = start; i < finish; i++) {
            char ch = str.charAt(i);
            result = result + ch;

        }
        return result;
    }
}



