package com.company;

public class Part7 {
    /*
    7.Реализовать метод, который принимает 2 параметра int start и int finish и возвращает сумму
всех чисел от start до finish включительно.
Например: sum(10,15) -> 75
     */
    public static void main(String[] args) {

    }
}
